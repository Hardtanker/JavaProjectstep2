package src.game.displayable.item;

public class Sword extends Item{

    public Sword(String masterSword){

    }
    public char getType() {
    	return '|';
    }
    public void setName(String masterSword){
        System.out.println(masterSword);
    }
    public void setId(int room, int serial){
        System.out.println("Room: " + room + " Serial: " + serial);
    }
}
