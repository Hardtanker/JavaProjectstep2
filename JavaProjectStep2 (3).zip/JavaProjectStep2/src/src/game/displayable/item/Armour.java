package src.game.displayable.item;

public class Armour extends Item{

    public Armour(String name){

    }
    
    public char getType() {
    	return ']';
    }

    public void setName(String name){
        System.out.println(name);
    }

    public void setId(int room, int serial){
        System.out.println("Room: " + room + " Serial: " + serial);
    }

}