package src.game.displayable.item;

import src.game.Displayable;
import src.game.ObjectDisplayGrid;
import src.game.displayable.creatures.Creature;

public class Item extends Displayable {
	
	Creature newPlayer;
	
    public Item() {
    	super('.');
    }

    public void setOwner(Creature Owner) {
        newPlayer = Owner;
    	System.out.println();
        
    }
    
    public void draw() {
    	if(newPlayer == null) {
    		ObjectDisplayGrid.addObjectToDisplay(this, newPosX, newPosY);
    	}
    }
    
}
