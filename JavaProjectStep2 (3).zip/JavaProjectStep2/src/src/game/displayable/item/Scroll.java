package src.game.displayable.item;

public class Scroll extends Item{
	
	
	
    public Scroll(String nameOfSrcoll){

    }
    public void setName(String nameOfSrcoll){
        System.out.println(nameOfSrcoll);
    }
    public void setId(int room, int serial){
        System.out.println("Room: " + room + " Serial: " + serial);
    }

}
