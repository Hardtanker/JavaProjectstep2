package src.game.displayable.structure;

public class PassageJunction extends TraversableStructure{
	public PassageJunction() {
		
	}
	
	public char getType() {
    	return '+';
    }
}
