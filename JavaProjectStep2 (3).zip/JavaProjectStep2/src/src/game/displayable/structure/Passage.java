
package src.game.displayable.structure;

import java.util.ArrayList;
import src.game.ObjectDisplayGrid;

public class Passage extends Structure{
	
	private String newName1;
	private String newName2;	
    private int newVisibility;
    private int newId1;
    private int newId2;
    private int newPosX;
    private int newPosY;
    private int newWidth;
    private int newHeight;
    ArrayList<Integer> positionX = new ArrayList<Integer>();
    ArrayList<Integer> positionY = new ArrayList<Integer>();
    
    public Passage(){
    	
    }
    
    public void addX(int x) {
    	positionX.add(x);
    }
    
    public void addY(int y) {
    	positionY.add(y);
    }
    
    public void draw() {
    	int p = 0;
    	for(int c = 0; c < positionX.size(); c++) {
    		int x1 = 0, x2 = 0, y1 = 0, y2 = 0;
    		if((p + 1) < positionX.size()) {
    			x1 = positionX.get(p);
    			x2 = positionX.get(p + 1);
    			y1 = positionY.get(p);
    			y2 = positionY.get(p + 1);
    		}
    		
    		if (x1 == x2) { 
    			if (y1 < y2) {
    				if(p == 0) {
    					ObjectDisplayGrid.addObjectToDisplay(new PassageJunction(), x1, y1);
    				}

    				for (int a = y1 + (p == 0 ? 1 : 0); a <= y2; a++) {
    					ObjectDisplayGrid.addObjectToDisplay(new PassageFloor(), x1, a);
    				}
    				if(((p + 1) == positionX.size() - 1)) {
    					ObjectDisplayGrid.addObjectToDisplay(new PassageJunction(), x2, y2);
    				}
    			} else {
    				if (p == 0) {
    					ObjectDisplayGrid.addObjectToDisplay(new PassageJunction(), x1, y1);
    				}
    				for (int b = y1 - (p == 0 ? 1 : 0); b >= y2; b--) {
    					ObjectDisplayGrid.addObjectToDisplay(new PassageFloor(), x1, b);
    				}
    				if ((p + 1) == positionX.size()-1) {
    					ObjectDisplayGrid.addObjectToDisplay(new PassageJunction(), x2, y2);
    				}
    			}
    		} else if(y1 == y2) {
    			if (x1 < x2) {
    				if(p == 0) {
    					ObjectDisplayGrid.addObjectToDisplay(new PassageJunction(), x1, y1);
    				}
    				for (int f = x1 + (p == 0 ? 1 : 0); f <= x2; f++) {
    					ObjectDisplayGrid.addObjectToDisplay(new PassageFloor(), f, y1);
    				}
    				if(((p + 1) == positionX.size() - 1)) {
    					ObjectDisplayGrid.addObjectToDisplay(new PassageJunction(), x2, y2);
    				}
    			} else {
    				if (p == 0) {
    					ObjectDisplayGrid.addObjectToDisplay(new PassageJunction(), x1, y1);
    				}
    				for (int g = x1 - (p == 0 ? 1 : 0); g >= x2; g--) {
    					ObjectDisplayGrid.addObjectToDisplay(new PassageFloor(), g, y1);
    				}
    				if ((p + 1) == positionX.size()-1) {
    					ObjectDisplayGrid.addObjectToDisplay(new PassageJunction(), x2, y2);

    				}
    			}
    		
    		}
    		p++;
    	}
    		
    		
    }
    

    public void getName(String name1, String name2){
    	this.newName1 = name1;
    	this.newName2 = name2;
        System.out.println("Room1: " + newName1 + " Room2: " + newName2);
    }

    public void setId(int room1, int room2){
    	this.newId1 = room1;
    	this.newId2 = room2;
        System.out.println("Room 1: " + newId1 + " Room 2: " + newId2);
    }
    
    public void setVisible(int visible) {
		newVisibility = visible;
		System.out.println("visibility set: " + newVisibility);
		
	}
	
	public void setPositionX(int x) {
		newPosX = x;
		System.out.println("x position: " + newPosX);
	}
	
	public void setPositionY(int y) {
		newPosY = y;
		System.out.println("y position: " + newPosY);
	}
	
	public void setWidth(int width) {
		newWidth = width;
		System.out.println("size of width: " + newWidth);
	}
	
	public void setHeight(int height) {
		newHeight = height;
		System.out.println("size of width: " + newHeight);
	}

}

//adapt keyboardprinter into a keyboard listener 
//define a move function
//x and y are parameters
//a bunch of if else statements
// stack of arrays
//redraw the entire dungeon every single time the player moves













