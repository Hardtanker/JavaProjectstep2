package src.game.displayable.structure;

public class RoomFloor extends TraversableStructure{
	public RoomFloor() {
		
	}
	
	public char getType() {
		return '.';
	}
	
}
