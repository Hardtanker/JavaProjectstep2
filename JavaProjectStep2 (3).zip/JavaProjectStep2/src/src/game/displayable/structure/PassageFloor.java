package src.game.displayable.structure;

public class PassageFloor extends TraversableStructure{
	public PassageFloor() {
		
	}
	
	public char getType() {
    	return '#';
    }
}
