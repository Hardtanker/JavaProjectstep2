package src.game.displayable.structure;

public class RoomWall extends Structure{
	public RoomWall() {
		
	}
	
	public char getType() {
		return 'X';
	}
}
