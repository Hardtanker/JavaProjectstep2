package src.game.displayable.structure;

import src.game.Displayable;

public class Structure extends Displayable{
	
	public Structure() {
		super('.');
	}
	
}
