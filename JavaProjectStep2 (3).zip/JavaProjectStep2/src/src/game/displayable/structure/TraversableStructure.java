package src.game.displayable.structure;

public class TraversableStructure extends Structure{
	public TraversableStructure() {
		
	}
}
