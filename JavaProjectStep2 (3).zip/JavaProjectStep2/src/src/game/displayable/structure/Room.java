package src.game.displayable.structure;

import src.game.ObjectDisplayGrid;

public class Room extends Structure{

    private String newName;
    private int newVisibility;
    public int newWidth;
    public int newHeight;

    public Room(String name) {
    	
        System.out.println("Creating Room");
    }

    public void getRoom(String name){
        newName = name;
    	System.out.println("Room name: " + newName);
    }

    public void draw() {
    	for(int a = 0; a < newWidth; a++) {
    		for (int b = 0; b < newHeight; b++) {
    			if((a * b == 0 ) || a == newWidth - 1 || b == newHeight - 1) {
					ObjectDisplayGrid.addObjectToDisplay(new RoomWall(), a + newPosX, b + newPosY);
    			} else {
    				ObjectDisplayGrid.addObjectToDisplay(new RoomFloor(), a + newPosX, b + newPosY);
    			}
    		}
    	}
    }
    
	public void setVisible(int visible) {
		newVisibility = visible;
		System.out.println("visibility set: " + newVisibility);
		
	}
	
	public void setPosX(int x) {
		newPosX = x;
		System.out.println("x position: " + newPosX);
	}
	
	public void setPosY(int y) {
		newPosY = y;
		System.out.println("y position: " + newPosY);
	}
	
	public void setWidth(int width) {
		newWidth = width;
		System.out.println("size of width: " + newWidth);
	}
	
	public void setHeight(int height) {
		newHeight = height;
		System.out.println("size of width: " + newHeight);
	} 
	public int getWidth() {
		return newWidth;
	}
	
	public int getHeight() {
		return newHeight;
	} 
	
}
