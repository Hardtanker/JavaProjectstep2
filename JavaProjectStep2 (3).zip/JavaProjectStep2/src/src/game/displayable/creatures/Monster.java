package src.game.displayable.creatures;

public class Monster extends Creature{

    public Monster(){
        System.out.println("Monster created");
    }


}
