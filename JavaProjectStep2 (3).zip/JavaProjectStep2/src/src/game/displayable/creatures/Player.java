package src.game.displayable.creatures;

import src.game.displayable.item.Item;

public class Player extends Creature{
	
	private Item newSword;
	private Item newArmour;
	
    public Player() {
        System.out.println("Player created");
        
    }
    @Override 
    public char getType() {
    	return '@'; 
    }
    
    public void setWeapon(Item sword){
    	newSword = sword;
        System.out.println("sword created: " + newSword);
    }

    public void setArmor(Item Armour){
    	newArmour = Armour;
    	System.out.println("armour created: " + newArmour);
    }
    
}
