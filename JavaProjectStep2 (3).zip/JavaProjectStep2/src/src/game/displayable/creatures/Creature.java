package src.game.displayable.creatures;

import src.game.Displayable;
import src.game.ObjectDisplayGrid;
import src.game.Action.creatureAction.CreatureAction;
import src.game.displayable.structure.Room;

public class Creature extends Displayable {
	
	private String newName;
	private Room newRoomObj;
	private int newRoom;
	private int newSerial;
	private int newHpMoves;
	private CreatureAction newDeath;
	private CreatureAction newHit;
	
    public Creature() {
    	super('.');
        System.out.println("Creature created");
    }
    
    public void draw() {
    	ObjectDisplayGrid.addObjectToDisplay(this, newPosX, newPosY);
    }
    
    public void setName(String name){
    	this.newName = name;
        System.out.println(newName);
    }
    
    public String getName() {
    	return newName;
    }
    public void setId(int room, int serial){
    	this.newRoom = room;
    	this.newSerial = serial;
        System.out.println("Room: " + newRoom + " Serial: "+ newSerial);
    }
    
    public void setRoom(Room room) {
    	newRoomObj = room;
    }

    public void setHpMoves(int hpMoves) {
    	this.newHpMoves = hpMoves;
        System.out.println("hpm: " + newHpMoves);
    }
    
    public void setDeathAction(CreatureAction death) {
    	this.newDeath = death;
        System.out.println("setDeathAction is being called: " + newDeath);
    }

    public void setHitAction(CreatureAction hit) {
    	this.newHit = hit;
        System.out.println("setHitAction is being called: " + newHit);
    }
    
    public void setPosX(int posX) {
    	this.newPosX = posX;
        System.out.println("x pos set: " + posX);
    }

    public void setPosY(int posY) {
    	this.newPosY = posY;
        System.out.println("y pos set: " + posY);
    }
    
    public int getSerial() {
    	return newSerial;
    }

//    
//    public int getPosX() {
//    	return newRoomObj.getPosX() + newPosX;
//    }
//    public int getPosY() {
//    	return newRoomObj.getPosY() + newPosY;
//    }
    
}
