package src.game.Action.creatureAction;


import src.game.displayable.creatures.Creature;

public class ChangedDisplayedType extends CreatureAction {

    public ChangedDisplayedType(String name, Creature owner){
        super(owner);
    }
}


