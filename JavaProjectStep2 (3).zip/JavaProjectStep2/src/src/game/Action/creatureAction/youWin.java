package src.game.Action.creatureAction;

import src.game.displayable.creatures.Creature;

public class youWin extends CreatureAction {

    public youWin(String name, Creature owner){
        super(owner);
        System.out.println("You Win");
    }
}


