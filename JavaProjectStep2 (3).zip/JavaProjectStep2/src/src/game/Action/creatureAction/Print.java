package src.game.Action.creatureAction;

public class Print {
	public Print() {
		System.out.println("print constructor");
	}
}
