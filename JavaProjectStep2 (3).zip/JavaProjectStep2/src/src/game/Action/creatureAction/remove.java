package src.game.Action.creatureAction;

import src.game.displayable.creatures.Creature;

public class remove extends CreatureAction {

    public remove(String name, Creature owner){
        super(owner);
        System.out.println("Remove");
    }
}


