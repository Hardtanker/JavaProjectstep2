package src.game.Action.creatureAction;

import src.game.action;
import src.game.displayable.creatures.Creature;

public class CreatureAction extends action {
    public CreatureAction(Creature owner) {

    }
}
