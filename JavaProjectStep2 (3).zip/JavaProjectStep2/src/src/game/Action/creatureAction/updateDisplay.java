package src.game.Action.creatureAction;

import src.game.displayable.creatures.Creature;

public class updateDisplay extends CreatureAction {

    public updateDisplay(String name, Creature owner){
        super(owner);
        System.out.println("Update Display");
    }
}


