package src.game.Action.creatureAction;

import src.game.displayable.creatures.Creature;

public class teleportOwner extends CreatureAction {

    public teleportOwner(String name, Creature owner){
        super(owner);
        System.out.println("TeleportOwner");
    }
}


