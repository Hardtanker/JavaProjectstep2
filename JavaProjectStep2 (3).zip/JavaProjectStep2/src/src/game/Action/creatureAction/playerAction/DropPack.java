package src.game.Action.creatureAction.playerAction;

import src.game.Action.creatureAction.CreatureAction;
import src.game.displayable.creatures.Creature;

public class DropPack extends CreatureAction {
    public DropPack(String name, Creature owner) {
        super(owner);
        System.out.println("DropPack method");
    }
}
