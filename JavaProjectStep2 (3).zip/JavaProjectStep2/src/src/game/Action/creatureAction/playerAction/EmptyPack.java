package src.game.Action.creatureAction.playerAction;

public class EmptyPack {
	public EmptyPack() {
		System.out.println("EmptyPack constructor");
	}
}
