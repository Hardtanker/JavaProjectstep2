package src.game.Action.creatureAction.playerAction;

import src.game.Action.creatureAction.CreatureAction;
import src.game.displayable.creatures.Creature;

public class Endgame extends CreatureAction {

    public Endgame(Creature owner){
        super(owner);
        System.out.println("EndGame method");
    }
}

