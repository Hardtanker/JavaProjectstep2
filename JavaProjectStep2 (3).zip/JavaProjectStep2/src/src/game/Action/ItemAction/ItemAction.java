package src.game.Action.ItemAction;

public class ItemAction {

	public void setMessage(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setIntValue(int parseInt) {
		// TODO Auto-generated method stub
		
	}

	public void setCharValue(char charAt) {
		// TODO Auto-generated method stub
		
	}

}
