package src.game.Action.ItemAction;

import src.game.displayable.creatures.Creature;
import src.game.displayable.item.Item;

public class Hallucinate extends ItemAction{

	public Hallucinate(Item item) {
		System.out.println("Hallucinate constructor\n");
	}
	public Hallucinate(Creature owner) {
		System.out.println("Hallucinate creature constructor\n");
	}

}
