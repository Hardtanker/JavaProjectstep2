package src.game.Action.ItemAction;

import src.game.displayable.item.Item;

public class BlessCurseOwner extends ItemAction{

	public BlessCurseOwner(Item item) {
		System.out.println("BlessCurseOwner constructor");
	}

}
