package src.game;

public class action {
    public action() {

    }
    private String newMessage;
    private int newValue;
    private char newCharValue;
    public void setMessage(String msg) {
        this.newMessage = msg;
        System.out.println(""+ newMessage);
    }

    public void setIntValue(int v) {
        this.newValue = v;
        System.out.println(""+ newValue);
    }

    public void setCharValue(char c) {
        this.newCharValue = c;
        System.out.println(""+ newCharValue);
    }
}
