package src.game;

import src.game.displayable.structure.Room;


public class Displayable {
    
	public int newVisible;
	public int newMaxHit;
	public int newHpMoves;
	public int newHp;
	public char newType;
	public int newValue;
	protected int newPosX;
	protected int newPosY;	
	
	public Displayable(char c) {

	}

    protected String getName(){
        return "Displayable";
    }

    public void setInvisible() {
        System.out.println("invisible set");
    }

    public void setVisible(int visibility) {
    	this.newVisible = visibility;
        System.out.println("visibility: " + visibility);
    }

    public void setMaxHit(int maxHit) {
    	this.newMaxHit = maxHit;
        System.out.println("max hit set: " + maxHit);
    }

    public void setHpMove(int hpMoves) {
    	this.newHpMoves = hpMoves;
        System.out.println("hp moves set: " + hpMoves);
    }

    public void setHp(int hp) {
    	this.newHp = hp;
        System.out.println("hp set: " + hp);
    }

    public void setType(char type) {
    	this.newType = type;
        System.out.println("type set: "+ type);
    }

    public void setIntValue(int value) {
    	this.newValue = value;
        System.out.println("int value set: " + value);
    }

    public void setPosX(int posX) {
    	this.newPosX = posX;
        System.out.println("x pos set: " + posX);
    }

    public void setPosY(int posY) {
    	this.newPosY = posY;
        System.out.println("y pos set: " + posY);
    }
    
    public void makePositionGlobal(Room newRoom) {
     newPosX += newRoom.getPosX();
     newPosY += newRoom.getPosY();
    }
    
    public int getPosX() {
    	return newPosX;
    }
    
    public int getPosY() {
    	return newPosY;
    }
    
    public char getType() {
    	return newType;
    }

}
