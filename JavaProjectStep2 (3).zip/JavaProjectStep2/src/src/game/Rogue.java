package src.game;

import java.util.Scanner;
import java.io.File;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;
import src.game.ObjectDisplayGrid;

public class Rogue implements Runnable {
    public static final int FRAMESPERSECOND = 60;
    public static final int TIMEPERLOOP = 1000000000 / FRAMESPERSECOND;
    private static ObjectDisplayGrid displayGrid = null;
    private Thread keyStrokePrinter;
    private static final int WIDTH = 80;
    private static final int HEIGHT = 40;
    public static Dungeon newDungeons = null;
    public static String fileName = null;
    
	public Rogue(int width, int height, Dungeon anotherDungeon) {
        displayGrid = new ObjectDisplayGrid(width, height, anotherDungeon);
    }
	
	public static void main(String[] args) throws InterruptedException {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter file number to test. 0 for dungeon.xml, 1 for testDrawing.xml, and 2 for dropPack.xml");
		int tester = input.nextInt();
		switch (tester) {
		case 2:
			fileName = "src/src/xmlFiles/" + "dropPack" + ".xml";
			break;
		case 1:
			fileName = "src/src/xmlFiles/" + "testDrawing" + ".xml";
			break;
		case 0:
			fileName = "src/src/xmlFiles/" + "dungeon" + ".xml";
			break;
		default: {
			System.out.println("java Test xmlFiles");
			input.close();
			return;
		}
		}
		input.close();
		System.out.printf(fileName);
		System.out.println("\n");
		
		
	SAXParserFactory parserFactory = SAXParserFactory.newInstance();
	
	try {
		SAXParser saxParser = parserFactory.newSAXParser();
		DungeonXMLHandler handler = new DungeonXMLHandler();
		saxParser.parse(new File(fileName), handler);
		newDungeons = handler.getDungeons();
    	System.out.println(newDungeons);
				
	} catch (ParserConfigurationException | SAXException | IOException e) {
        e.printStackTrace(System.out);
    }
	
	//-- step 2
		Rogue rougue = new Rogue(WIDTH, HEIGHT, newDungeons);
		Thread testThread = new Thread(rougue);
		testThread.start();
		rougue.keyStrokePrinter = new Thread(new KeyStrokePrinter(displayGrid));
		rougue.keyStrokePrinter.start();
	    testThread.join();
	    rougue.keyStrokePrinter.join();
	    
	    Thread listener = new Thread();
	//do threads for drawing the output and listening to the keyinput
	}
	

	public void run() {
        displayGrid.fireUp();
        newDungeons.draw();
        //draw 	
    }
}

