package src.game;

import src.game.Action.ItemAction.BlessCurseOwner;
import src.game.Action.ItemAction.Hallucinate;
import src.game.Action.ItemAction.ItemAction;
import src.game.Action.creatureAction.*;
import src.game.Action.creatureAction.playerAction.DropPack;
import src.game.Action.creatureAction.playerAction.Endgame;
import src.game.displayable.item.*;
import src.game.displayable.structure.Passage;
import src.game.displayable.structure.Room;
import src.game.displayable.creatures.Creature;
import src.game.displayable.creatures.Monster;
import src.game.displayable.creatures.Player;
import src.game.displayable.item.Item;
import src.game.displayable.item.Scroll;
import src.game.displayable.item.Sword;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class DungeonXMLHandler extends DefaultHandler {

    private StringBuilder data = null;

    private CreatureAction creatureActionBeingParsed = null;
    private ItemAction itemActionBeingParsed = null;
    private Passage passageBeingParsed = null;
    private Monster monsterBeingParsed = null;
    public Dungeon dungeonBeingParsed = null;
    private Armour armourBeingParsed = null;
    private Scroll scrollBeingParsed = null;
    private Player playerBeingParsed = null;
    private Sword swordBeingParsed = null;
    private Room roomBeingParsed = null;
    private Item itemBeingParsed = null;


    public Dungeon getDungeons() {
        return dungeonBeingParsed;
    }

    public DungeonXMLHandler() {
    }

    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {

        if (qName.equalsIgnoreCase("Dungeon")) {
            String name = attributes.getValue("name");
            String width = attributes.getValue("width");
            String topHeight = attributes.getValue("topHeight");
            String gameHeight = attributes.getValue("gameHeight");
            String bottomHeight = attributes.getValue("bottomHeight");
            dungeonBeingParsed = new Dungeon(name, width, topHeight, gameHeight, bottomHeight);
            dungeonBeingParsed.getDungeon();

        } else if (qName.equalsIgnoreCase("Room")) {
            String name = attributes.getValue("room");
            roomBeingParsed = new Room(name);
            dungeonBeingParsed.addRoom(roomBeingParsed);
            roomBeingParsed.getRoom(name);

        }else if (qName.equalsIgnoreCase("Passage")) {
                String name1 = attributes.getValue("room1");
                String name2 = attributes.getValue("room2");
                passageBeingParsed = new Passage();
                 dungeonBeingParsed.addPassage(passageBeingParsed);
                passageBeingParsed.getName(name1,name2);
                
        } else if (qName.equalsIgnoreCase("Monster")) {
            String name = attributes.getValue("name");
            int room = Integer.parseInt(attributes.getValue("room"));
            int serial = Integer.parseInt(attributes.getValue("serial"));
            monsterBeingParsed = new Monster();
            monsterBeingParsed.setName(name);
            monsterBeingParsed.setRoom(roomBeingParsed);
            monsterBeingParsed.setId(room, serial);
            dungeonBeingParsed.addCreature(monsterBeingParsed);

        } else if (qName.equalsIgnoreCase("Player")) {
            String name = attributes.getValue("name");
            int room = Integer.parseInt(attributes.getValue("room"));
            int serial = Integer.parseInt(attributes.getValue("serial"));
            playerBeingParsed = new Player();
            playerBeingParsed.setName(name);
            playerBeingParsed.setId(room, serial);
            dungeonBeingParsed.addCreature(playerBeingParsed);
        } else if (qName.equalsIgnoreCase("CreatureAction")) {
            String name = attributes.getValue("name");
            String type = attributes.getValue("type");
            CreatureAction creatureAction = null;
            Creature creature = null;
            if (monsterBeingParsed != null)
                creature = monsterBeingParsed;
            else
                creature = playerBeingParsed;
            switch (name) {
                case "EndGame":
                    creatureAction = new Endgame(creature);
                    break;
                case "Remove":
                    creatureAction = new remove(name, creature);
                    break;
                case "YouWin":
                    creatureAction = new youWin(name, creature);
                    break;
                case "ChangeDisplayedType":
                    creatureAction = new ChangedDisplayedType(name, creature);
                    break;
                case "UpdateDisplay":
                    creatureAction = new updateDisplay(name, creature);
                    break;
                case "DropPack":
                    creatureAction = new DropPack(name, creature);
                    break;
                case "Teleport":
                    creatureAction = new teleportOwner(name, creature);
                    break;
                default:
                    System.out.println("Unknown action: " + name);
                    break;
            }

            if (type.equals("death")) {
                creature.setDeathAction(creatureAction);
            } else
                creature.setHitAction(creatureAction);
            creatureActionBeingParsed = creatureAction;


        } else if (qName.equalsIgnoreCase("Armor")) {
            String name = attributes.getValue("name");
            String room = attributes.getValue("room");
            String serial = attributes.getValue("serial");
            armourBeingParsed = new Armour(name);
            armourBeingParsed.setName(name);
            armourBeingParsed.setId(Integer.parseInt(room), Integer.parseInt(serial));
            if(playerBeingParsed != null) {
            	armourBeingParsed.setOwner(playerBeingParsed);
            }
            dungeonBeingParsed.addItem(armourBeingParsed);
        } else if (qName.equalsIgnoreCase("Scroll")) {
            String name = attributes.getValue("name");
            String room = attributes.getValue("room");
            String serial = attributes.getValue("serial");
            scrollBeingParsed = new Scroll(name);
            scrollBeingParsed.setName(name);
            scrollBeingParsed.setId(Integer.parseInt(room), Integer.parseInt(serial));
            if(playerBeingParsed != null) {
            	scrollBeingParsed.setOwner(playerBeingParsed);
            }
            dungeonBeingParsed.addItem(scrollBeingParsed);
        }else if (qName.equalsIgnoreCase("Sword")) {
                String name = attributes.getValue("name");
                String room = attributes.getValue("room");
                String serial = attributes.getValue("serial");
                swordBeingParsed = new Sword(name);
                swordBeingParsed.setName(name);
                swordBeingParsed.setId(Integer.parseInt(room), Integer.parseInt(serial));
                if(playerBeingParsed != null) {
                	swordBeingParsed.setOwner(playerBeingParsed);
                }
                dungeonBeingParsed.addItem(swordBeingParsed);

        } else if (qName.equalsIgnoreCase("ItemAction")){
            String name = attributes.getValue("name");
         //   String type = attributes.getValue("type");
            ItemAction itemAction = null;
            Item item = null;

            if(scrollBeingParsed != null){
                switch (name){
                    case "BlessArmor":
                        itemAction = new BlessCurseOwner(item);
                        break;
                    case "Hallucinate":
                        itemAction = new Hallucinate(item);
                        break;
                }
            }
            itemActionBeingParsed = itemAction;
        }

        data = new StringBuilder();
        }
    	//three items, item itself, monster, player, room and passage

        public void endElement(String uri, String localName, String qName) throws SAXException {

            if(qName.equalsIgnoreCase("visible")){

                if(swordBeingParsed != null) {
                	swordBeingParsed.setVisible(Integer.parseInt(data.toString()));
                } else if (scrollBeingParsed != null) {
                	scrollBeingParsed.setVisible(Integer.parseInt(data.toString()));
                } else if (armourBeingParsed != null) {
                	armourBeingParsed.setVisible(Integer.parseInt(data.toString()));
                } else if (itemBeingParsed != null) {
                	itemBeingParsed.setVisible(Integer.parseInt(data.toString()));
                } else if (monsterBeingParsed != null) {
                	monsterBeingParsed.setVisible(Integer.parseInt(data.toString()));
                } else if (playerBeingParsed != null) {
                	playerBeingParsed.setVisible(Integer.parseInt(data.toString()));
                } else if(roomBeingParsed != null) {
                    roomBeingParsed.setVisible(Integer.parseInt(data.toString()));
                } else if(passageBeingParsed != null){
                    passageBeingParsed.setVisible(Integer.parseInt(data.toString()));
                }

            } else if(qName.equalsIgnoreCase("posX")){

            	if(swordBeingParsed != null) {
                	swordBeingParsed.setPosX(Integer.parseInt(data.toString()));
                } else if (scrollBeingParsed != null) {
                	scrollBeingParsed.setPosX(Integer.parseInt(data.toString()));
                } else if (armourBeingParsed != null) {
                	armourBeingParsed.setPosX(Integer.parseInt(data.toString()));
                } else if (itemBeingParsed != null) {
                	itemBeingParsed.setPosX(Integer.parseInt(data.toString()));
                } else if (monsterBeingParsed != null) {
                	monsterBeingParsed.setPosX(Integer.parseInt(data.toString()));
                } else if (playerBeingParsed != null) {
                	playerBeingParsed.setPosX(Integer.parseInt(data.toString())); // + roomBeingParsed);
                } else if(roomBeingParsed != null) {
                    roomBeingParsed.setPosX(Integer.parseInt(data.toString()));
                } else if(passageBeingParsed != null){
                    passageBeingParsed.setPosX(Integer.parseInt(data.toString()));
                    passageBeingParsed.addX(passageBeingParsed.getPosX());
                }

            } else if(qName.equalsIgnoreCase("posY")) {
            	if(swordBeingParsed != null) {
                	swordBeingParsed.setPosY(Integer.parseInt(data.toString()));
                } else if (scrollBeingParsed != null) {
                	scrollBeingParsed.setPosY(Integer.parseInt(data.toString()));
                } else if (armourBeingParsed != null) {
                	armourBeingParsed.setPosY(Integer.parseInt(data.toString()));
                } else if (itemBeingParsed != null) {
                	itemBeingParsed.setPosY(Integer.parseInt(data.toString()));
                } else if (monsterBeingParsed != null) {
                	monsterBeingParsed.setPosY(Integer.parseInt(data.toString()));
                } else if (playerBeingParsed != null) {
                	playerBeingParsed.setPosY(Integer.parseInt(data.toString()));
                } else if(roomBeingParsed != null) {
                    roomBeingParsed.setPosY(Integer.parseInt(data.toString()));
                } else if(passageBeingParsed != null){
                    passageBeingParsed.setPosY(Integer.parseInt(data.toString()));
                    passageBeingParsed.addY(passageBeingParsed.getPosY());
                }

            } else if(qName.equalsIgnoreCase("ItemIntValue")) {
                if (scrollBeingParsed != null){
                    scrollBeingParsed.setIntValue(Integer.parseInt(data.toString()));
                }
                else if (armourBeingParsed != null) {
                    armourBeingParsed.setIntValue(Integer.parseInt(data.toString()));
                } else if (swordBeingParsed != null){
                    swordBeingParsed.setIntValue(Integer.parseInt(data.toString()));
                }

            } else if(qName.equalsIgnoreCase("width")) {
                roomBeingParsed.setWidth(Integer.parseInt(data.toString()));

            } else if(qName.equalsIgnoreCase("height")) {
                roomBeingParsed.setHeight(Integer.parseInt(data.toString()));

            } else if(qName.equalsIgnoreCase("type")) {
                monsterBeingParsed.setType(data.toString().charAt(0));

            } else if(qName.equalsIgnoreCase("hp")) {
                if(monsterBeingParsed != null) {
                    monsterBeingParsed.setHp(Integer.parseInt(data.toString()));
                } else if(playerBeingParsed != null){
                    playerBeingParsed.setHp(Integer.parseInt(data.toString()));
                }else
                    System.out.println("No hp");

            } else if(qName.equalsIgnoreCase("maxhit")) {
                if (monsterBeingParsed != null) {
                    monsterBeingParsed.setMaxHit(Integer.parseInt(data.toString()));
                } else if (playerBeingParsed != null) {
                    playerBeingParsed.setMaxHit(Integer.parseInt(data.toString()));
                }

            } else if(qName.equalsIgnoreCase("hpMoves")) {
                playerBeingParsed.setHpMove(Integer.parseInt(data.toString()));

            } else if(qName.equalsIgnoreCase("actionMessage")) {
                if (creatureActionBeingParsed != null)
                    creatureActionBeingParsed.setMessage(data.toString());
                else if(itemActionBeingParsed != null)
                    itemActionBeingParsed.setMessage(data.toString());

            } else if(qName.equalsIgnoreCase("actionIntValue")) {
                if (creatureActionBeingParsed != null)
                    creatureActionBeingParsed.setIntValue(Integer.parseInt(data.toString()));
                else if(itemActionBeingParsed != null)
                    itemActionBeingParsed.setIntValue(Integer.parseInt(data.toString()));

            } else if(qName.equalsIgnoreCase("actionCharValue")) {
                if (creatureActionBeingParsed != null)
                    creatureActionBeingParsed.setCharValue(data.toString().charAt(0));
                else if(itemActionBeingParsed != null)
                    itemActionBeingParsed.setCharValue(data.toString().charAt(0));

            } else if (qName.equalsIgnoreCase("CreatureAction")) {
                creatureActionBeingParsed = null;

            } else if (qName.equalsIgnoreCase("Player")) {
            	playerBeingParsed.makePositionGlobal(roomBeingParsed);
                playerBeingParsed = null;

            } else if (qName.equalsIgnoreCase("Monster")) {
            	monsterBeingParsed.makePositionGlobal(roomBeingParsed);
                monsterBeingParsed = null;

            } else if (qName.equalsIgnoreCase("ItemAction")) {
                itemActionBeingParsed = null;

            } else if (qName.equalsIgnoreCase("Scroll")){
            	scrollBeingParsed.makePositionGlobal(roomBeingParsed);
            	scrollBeingParsed = null;

            } else if (qName.equalsIgnoreCase("Armor")){
            	armourBeingParsed.makePositionGlobal(roomBeingParsed);
                armourBeingParsed = null;

            } else if (qName.equalsIgnoreCase("Sword")){
            	swordBeingParsed.makePositionGlobal(roomBeingParsed);
                swordBeingParsed = null;

            } else if (qName.equalsIgnoreCase("Item")) {
            	itemBeingParsed.makePositionGlobal(roomBeingParsed);
            	itemBeingParsed = null;

            } else if (qName.equalsIgnoreCase("Room")) {
                roomBeingParsed = null;
            }
        }
    @Override
    public void characters(char ch[], int start, int length) throws SAXException {
        data.append(new String(ch, start, length));
    }
    
}



