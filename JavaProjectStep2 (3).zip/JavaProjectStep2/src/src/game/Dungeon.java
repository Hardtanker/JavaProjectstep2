package src.game;

import src.game.displayable.creatures.Creature;
import src.game.displayable.item.Armour;
import src.game.displayable.item.Item;
import src.game.displayable.item.Scroll;
import src.game.displayable.item.Sword;
import src.game.displayable.structure.Passage;
import src.game.displayable.structure.Room;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Dungeon {
    private String name;
    private int width;
    private int topHeight;
    private int gameHeight;
    private int bottomHeight;
    private ArrayList<Room> rooms = new ArrayList<Room>();
    private ArrayList<Creature> creatures = new ArrayList<Creature>();
    private ArrayList<Passage> passages = new ArrayList<Passage>();
    private ArrayList<Item> items = new ArrayList<Item>();
    
    public Dungeon(String _name, String _width, String _topHeight, String _gameHeight, String _bottomHeight) {
        name = _name;
        this.width = Integer.parseInt(_width);
        this.topHeight = Integer.parseInt(_topHeight);
        this.gameHeight = Integer.parseInt(_gameHeight);
        this.bottomHeight = Integer.parseInt(_bottomHeight);
    }
    
    public void getDungeon () {
        System.out.println("Name: " + name + " Width: " + width + " GameHeight: " + gameHeight + " TopHeight: " + topHeight + " BottomHeight: "+ bottomHeight );
    }
    
    public void draw() {
    	for(int a = 0; a < rooms.size(); a++) {
    		Room room = rooms.get(a);
    		room.draw();
    	}
    	
    	for(int c = 0; c < items.size(); c++) {
    		Item item = items.get(c);
    		item.draw();
    	}
    	
    	for(int b = 0; b < creatures.size(); b++) {
    		Creature creature = creatures.get(b);
    		creature.draw();
    	}
    	
    	for(int d = 0; d < passages.size(); d++) {
    		Passage passage = passages.get(d);
    		passage.draw();
    	}
    	
    	
    }
    
    public void addRoom (Room newRoom) {
        System.out.println("Room added");
        rooms.add(newRoom);
    }

    public void addCreature (Creature newCreature) {
        creatures.add(newCreature);
    }

    public void addPassage (Passage newPassage) {
        System.out.println("Passage Added");
        passages.add(newPassage);
    }
    
    public void addItem (Item item) {
    	System.out.println("Item added: " + item);
    	items.add(item);
    }
    
    public int getWidth() {
    	return width;
    }
    
    public int getHeight() {
    	return gameHeight;
    }
    
    public ArrayList<Creature> getCreature() {
    	return creatures;
    }
    
    public ArrayList<Item> getItems() {
    	return items;
    }

	public ArrayList<Room> getRooms() {
		return rooms;
	}
}
