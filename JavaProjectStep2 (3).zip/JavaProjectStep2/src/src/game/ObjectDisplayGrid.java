package src.game;


import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import javax.swing.*;
import src.game.asciiPanel.AsciiPanel;
import src.game.displayable.creatures.Creature;
import src.game.displayable.item.Item;
import src.game.displayable.structure.Room;

import java.time.format.DateTimeFormatter;  
import java.time.LocalDateTime;


@SuppressWarnings("serial")
public class ObjectDisplayGrid extends JFrame implements KeyListener, InputSubject {

    private static final String CLASSID = ".ObjectDisplayGrid";

    private static AsciiPanel terminal;
    private static Stack<Displayable>[][] objectGrid;
    
    private List<InputObserver> inputObservers = null;
    public List<Item> inventory = new ArrayList<Item>();

    private static int height;
    private static int width;
    private Dungeon dungeon;
    
    private boolean GameOver = false;


    @SuppressWarnings("unchecked")
	public ObjectDisplayGrid(int _width, int _height, Dungeon _dungeon) {
        width = _width;
        height = _height;
        dungeon = _dungeon;

        terminal = new AsciiPanel(width, height);

        objectGrid = new Stack[width][height];
        
        for(int a = 0; a < width; a++) {
        	for(int b = 0; b < height; b++) {
        		objectGrid[a][b] = new Stack<Displayable>();
        	}
        }

        initializeDisplay();

        super.add(terminal);
        super.setSize(width * 9, height * 16);
        super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        // super.repaint();
        // terminal.repaint( );
        super.setVisible(true);
        terminal.setVisible(true);
        super.addKeyListener(this);
        terminal.addKeyListener(this);
        inputObservers = new ArrayList<>();
        super.repaint();
        
        
    }

    @Override
    public void registerInputObserver(InputObserver observer) {

        inputObservers.add(observer);
    }

    // public void keyTyped(KeyEvent e, Dungeon dungeon) {

    // }
    
//    private boolean MapRangeCheck(int x, int y){
//		return false;
//        //check size of map and check if movable
//    } 
    
    private void pickItem(int x, int y){
        for (int i=dungeon.getItems().size()-1; i >=0;i--){
            Item item = dungeon.getItems().get(i);
            if(item.newPosY == y && item.newPosX == x){
                inventory.add(item);
                dungeon.getItems().remove(i);
                
                //item needs to be set first
                System.out.println("Picked up: "+ item.getName());

                //display time picked
                DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
                LocalDateTime now = LocalDateTime.now();  
                System.out.println(dtf.format(now)); 
            }
        }
    }
    
    private void dropItem(int x, int y){
        if(inventory.size() > 0){
            //Drop the last item in bag
            Item item = inventory.get(inventory.size() - 1);
            item.newPosY = y;
            item.newPosX = x;
            dungeon.getItems().add(item);
            inventory.remove(inventory.size() - 1);
        }
    }
    
    private void notifyInputObservers(char ch) {
        for (InputObserver observer : inputObservers) {
            observer.observerUpdate(ch);
            
        }
    }

    // we have to override, but we don't use this
    @Override
    public void keyPressed(KeyEvent even) {
    }

    // we have to override, but we don't use this
    @Override
    public void keyReleased(KeyEvent e) {
    }

    public final void initializeDisplay() {
        Displayable ch = new Displayable('.');
        for (int i = 0; i < width; i++) {
            for (int j = 0; j < height; j++) {
                addObjectToDisplay(ch, i, j);
            }
        }
        terminal.repaint();
    }

    public void fireUp() {
        if (this.requestFocusInWindow()) {
            System.out.println(CLASSID + ".ObjectDisplayGrid(...) requestFocusInWindow Succeeded");
        } else {
            System.out.println(CLASSID + ".ObjectDisplayGrid(...) requestFocusInWindow FAILED");
        }
    }

    public static void addObjectToDisplay(Displayable ch, int x, int y) {
        if ((0 <= x) && (x < objectGrid.length)) {
            if ((0 <= y) && (y < objectGrid[0].length)) {
                objectGrid[x][y].push(ch);
            	writeToTerminal(x, y);
            }
        }
    }
    
    
    private static void writeToTerminal(int x, int y) {
        char ch = objectGrid[x][y].peek().getType();
        terminal.write(ch, x, y);
        terminal.repaint();
    }

	@Override
	public void keyTyped(KeyEvent e) {
        KeyEvent keypress = (KeyEvent) e;
        notifyInputObservers(keypress.getKeyChar());
        
        char key = keypress.getKeyChar();
        
        
        int dCreatureSize = dungeon.getCreature().size();
        for (int q = 0; q < dCreatureSize; q++) {
        	if(dungeon.getCreature().get(q).getName().equals("Player")) {
        		if(GameOver == false) {
                	Creature creature = dungeon.getCreature().get(q);
                	
                	switch (key) {
                		case 'h':
                			if(objectGrid[creature.newPosX - 1][creature.newPosY].peek().getType() == 'X' || objectGrid[creature.newPosX - 1][creature.newPosY].peek().getType() == '\0') {
            					System.out.println("Running into wall"); 
            				
                			} else {
                				Displayable another = objectGrid[creature.newPosX][creature.newPosY].pop();
                				Displayable first = objectGrid[creature.newPosX][creature.newPosY].peek();
                				ObjectDisplayGrid.addObjectToDisplay(first, creature.newPosX, creature.newPosY);
                				creature.setPosX((creature.newPosX) - 1);
                				ObjectDisplayGrid.addObjectToDisplay(another, creature.newPosX, ((creature.newPosY)));
                			}
                				System.out.println("h: move left");
                			break;
                		case 'l': 
                			if(objectGrid[creature.newPosX + 1][creature.newPosY].peek().getType() == 'X' || objectGrid[creature.newPosX - 1][creature.newPosY].peek().getType() == '\0') {
                					System.out.println("Running into wall");
                		
                			} else {
                				Displayable another = objectGrid[creature.newPosX][creature.newPosY].pop();
                				Displayable first = null;
                				if(objectGrid[creature.newPosX][creature.newPosY].peek() != null) {
                					first = objectGrid[creature.newPosX][creature.newPosY].peek();
                				} else {
                					System.out.println("Cann");
                				}
                				ObjectDisplayGrid.addObjectToDisplay(first, creature.newPosX, creature.newPosY);
                				creature.setPosX((creature.newPosX) + 1);
                				ObjectDisplayGrid.addObjectToDisplay(another, creature.newPosX, ((creature.newPosY)));
                			}
                            System.out.println("l: move right");
                            break;
                		case 'k':
                				if(objectGrid[creature.newPosX][creature.newPosY + 1].peek().getType() == 'X'|| objectGrid[creature.newPosX - 1][creature.newPosY].peek().getType() == '\0') {
            						System.out.println("Running into wall");
                				} else {
                				Displayable another = objectGrid[creature.newPosX][creature.newPosY].pop();
            					Displayable first = objectGrid[creature.newPosX][creature.newPosY].peek();
            					ObjectDisplayGrid.addObjectToDisplay(first, creature.newPosX, creature.newPosY);
            					creature.setPosY((creature.newPosY) + 1);
            					ObjectDisplayGrid.addObjectToDisplay(another, creature.newPosX, ((creature.newPosY)));
                			}
                			System.out.println("k: move up");
                            break;
                		case 'j':
                 				if(objectGrid[creature.newPosX][creature.newPosY - 1].peek().getType() == 'X'|| objectGrid[creature.newPosX - 1][creature.newPosY].peek().getType() == '\0') {
        							System.out.println("Running into wall");
            					} else {
            					Displayable another = objectGrid[creature.newPosX][creature.newPosY].pop();
        						Displayable first = objectGrid[creature.newPosX][creature.newPosY].peek();

        						ObjectDisplayGrid.addObjectToDisplay(first, creature.newPosX, creature.newPosY);
        						creature.setPosY((creature.newPosY) - 1);
        						ObjectDisplayGrid.addObjectToDisplay(another, creature.newPosX, ((creature.newPosY)));
            				}                           
                			System.out.println("j: move down");
                            break;
                		case 'p':
                                Displayable another = objectGrid[creature.newPosX][creature.newPosY].pop();
                                if (objectGrid[creature.newPosX][creature.newPosY].peek().getType() == '|' || objectGrid[creature.newPosX][creature.newPosY].peek().getType() == ']' || objectGrid[creature.newPosX][creature.newPosY].peek().getType() == '?') {
                                	inventory.add((Item) objectGrid[creature.newPosX][creature.newPosY].peek());
                                	objectGrid[creature.newPosX][creature.newPosY].pop();
                                	Displayable first = objectGrid[creature.newPosX][creature.newPosY].peek();
                                	ObjectDisplayGrid.addObjectToDisplay(first, creature.newPosX, creature.newPosY);
                                	ObjectDisplayGrid.addObjectToDisplay(another, creature.newPosX, creature.newPosY);
                                }
                                break;
                		case 'd':
                				if (inventory.size() > 0) {
                					Item item = inventory.get(0);
                					inventory.remove(0);
                					
                					Displayable another2 = objectGrid[creature.newPosX][creature.newPosY].pop();
                					objectGrid[creature.newPosX][creature.newPosY].push(item);
                					ObjectDisplayGrid.addObjectToDisplay(item, creature.newPosX, creature.newPosY);
                                	ObjectDisplayGrid.addObjectToDisplay(another2, creature.newPosX, creature.newPosY);
                				}
                                System.out.println("d: drop item");
                                break;
                	}
                }
        	}
        }
    }		
}

//


//add method that gets object at that position
//ObjectDisplayGrid.addObjectToDisplay('H', creature.newPosX, creature.newPosY);
